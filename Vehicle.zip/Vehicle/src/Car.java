//Aidan Hall
public class Car extends Vehicle{

    private double mileage;

    private int passengers;

    public Car(){
        super();
        this.mileage = 1;
        this.passengers = 1;
    }
    public Car(String xManuName, int xCylinders, String xOwnersName, double xMileage, int xPassengers){
        super(xManuName,xCylinders,xOwnersName);
        this.setMileage(xMileage);
        this.setPassengers(xPassengers);
        // Not many new things going on here... no issues so far
    }
    public double getMileage(){
        return this.mileage;
    }
    public int getPassengers(){
        return this.passengers;
    }
    public void setMileage(double xMileage){
        if (xMileage >= 0){
            this.mileage = xMileage;
        }
        else {
            System.out.println("Invalid mileage entered!");
        }
    }
    // I actually ran into many bugs across a few of my classes, however they were either syntax errors, or really strange errors that required me to simply update the variable that i created after I typed it out.
    public void setPassengers(int xPassengers){
        if (xPassengers >= 0){
            passengers = xPassengers; 
        }
        else {
            System.out.println("Invalid amount of passengers entered!");
        }
    }
    //Forgot to add a String toString method
    //Also didnt know that you could add a super method to what's after
    public String toString(){
        return super.toString()+("\nMileage:"+this.mileage+"\nPassengers:"+this.passengers);
    }
}
