//Aidan Hall
public class Truck extends Vehicle{

    private double loadCap;

    private double towCap;

    public Truck(){
        super();
        this.loadCap = 1;
        this.towCap = 1;
    }
    public Truck(String xManuName, int xCylinders, String xOwnersName, double xloadCap, double xtowCap){
        super(xManuName,xCylinders,xOwnersName);
        this.setloadCap(xloadCap);
        this.settowCap(xtowCap);
    }
    //Had minimum issues within this class...
    public double getLoadCap(){
        return this.loadCap;
    }
    public double getTowCap(){
        return this.towCap;
    }
    public void setloadCap(double xLoadCap){
        if (loadCap >= 0){
            this.loadCap = xLoadCap;
        }
        else {
            System.out.println("Invalid load capacity entered!");
        }
    }
    public void  settowCap(double xTowCap){
        if (towCap >= 0){
            this.towCap = xTowCap;
        }
        else {
            System.out.println("Invalid tow capacity entered!");
        }
    }
    //When I first tested the ToString method was not here, so when testing no values were displayed...
    public String toString(){
        return super.toString()+("\nLoad Capacity:"+this.loadCap+"\nTow Capacity:" +this.towCap);
    }

}
