//Aidan Hall
public class Vehicle {
    private String manuName;

    private int Cylinders;

    private String ownersName;

    public Vehicle(){
        this.manuName = "Unknown Manufacturer";
        this.Cylinders = 1;
        this.ownersName = "Unknown Owner";
    }
    public Vehicle(String xManuName, int xCylinders, String xOwnersName) {
        this.setManuName(xManuName);
        this.setCylinders(xCylinders);
        this.setOwnersName(xOwnersName);
    }
    public String getManuName(){
        return this.manuName;
    }
    public int getCylinders(){
        return this.Cylinders;
    }
    public String getOwnersName(){
        return this.ownersName;
    }
    public void setManuName(String xManuName){
        this.manuName = xManuName;
    }
    public void setCylinders(int xCylinders){
        if (xCylinders > 0){
            this.Cylinders = xCylinders;
        }
        else {
            System.out.println("Invalid amount of Cylinders!");
        }
// Had very minimal issues within this class. I feel that i'm getting used to constructors, mutators, getters and setters.
    }
    public void setOwnersName(String xOwnersName){
        this.ownersName = xOwnersName;
    }
    //had trouble preventing this string from being overridden.
    public String toString(){
        return ("Manufacturer's Name:"+this.manuName+"\nCylinders:"+this.Cylinders+"\nOwner's Name:"+ this.ownersName);
    }
}
