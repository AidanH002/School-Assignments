import java.util.Scanner;
public class Main {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        GenericLinkedList<VideoGame> gameList = new GenericLinkedList<>();

        // Prompt user for file name and populate game list
        System.out.println("Enter the name of the game collection file: ");
        String fileName = input.nextLine();

        if (FileIO.readFile(fileName, gameList)) {
            System.out.println("File read successfully.");
        } else {
            System.out.println("Error reading file.");
            return;
        }

        // User input loop
        String queryTitle;
        String queryConsole;

        while (true) {
            System.out.println("Type 'quit' to exit the program.");
            System.out.println("\nEnter the title of the game to search for (* for all): ");
            queryTitle = input.nextLine();

            if (queryTitle.equalsIgnoreCase("quit")) {
                System.out.println("Exiting program...");
                break;
            }

            System.out.println("Enter the console of the game to search for (* for all): ");
            queryConsole = input.nextLine();

            if (queryConsole.equalsIgnoreCase("quit")) {
                System.out.println("Exiting program...");
                break;
            }

            // Search for matching games
            GenericLinkedList<VideoGame> searchResults = gameList.search(queryTitle, queryConsole);

            // Print search results to console
            if (searchResults.isEmpty()) {
                System.out.println("No matches found.");
            } else {
                System.out.println("Search results:");
                for (VideoGame game : searchResults) {
                    System.out.println(game.getTitle() + "\t" + game.getConsole());
                }

                // Ask user if they want to write the results to a file
                System.out.println("Would you like to write the results to a file? (y/n)");
                String response = input.nextLine();

                if (response.equalsIgnoreCase("y")) {
                    if (FileIO.writeToFile("search_results.txt", searchResults.toString())) {
                        System.out.println("Results written to file.");
                    }
                }
            }
        }

        input.close();
    }
}

