// Aidan Hall

import java.io.*;
import java.util.Scanner;
// This class contains all of my file operations. I thought I'd seperate it's class for reference.
public class FileIO {
    public static boolean readFile(String filename, GenericLinkedList<VideoGame> gameList) {
        try {
            Scanner scanner = new Scanner(new File(filename));
            scanner.useDelimiter("\\t"); // set delimiter to tab character
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] fields = line.split("\\t");
                if (fields.length != 2) {
                    continue;
                }
                VideoGame game = new VideoGame(fields[0].trim(), fields[1].trim());
                gameList.add(game);
            }
            scanner.close();
            return true;
        } catch (FileNotFoundException e) {
            System.out.println("File not found.");
            return false;
        }
    }
    // When writing to a file, the user should specify the type of file it's writing or else it wont work.
    // Out of laziness I did not add an implementation that suits.
    public static boolean writeToFile(String fileName, String data) {
        try (FileWriter writer = new FileWriter(fileName)) {
            writer.write(data);
            System.out.println("Results written to file: " + fileName);
            return true;
        } catch (IOException e) {
            System.out.println("Error writing to file: " + fileName);
            e.printStackTrace();
            return false;
        }
    }
}
