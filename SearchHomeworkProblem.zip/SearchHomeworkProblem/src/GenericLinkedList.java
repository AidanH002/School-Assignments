import java.util.NoSuchElementException;
import java.util.Iterator;

public class GenericLinkedList<T extends VideoGame> implements Iterable<T> {
    private Node head;
    private Node tail;
    private int size;

    public GenericLinkedList() {
        head = null;
        size = 0;
    }

    public void add(T data) {
        Node newNode = new Node(data, null);

        if (tail == null) {
            head = newNode;
        } else {
            tail.next = newNode;
        }

        tail = newNode;
        size++;
    }
// Was worried I implemented the search method JJ was talking about that allows to search like this example..
    // Mega Ninten*
    public GenericLinkedList<T> search(String queryTitle, String queryConsole) {
        GenericLinkedList<T> results = new GenericLinkedList<>();

        Node current = head;

        while (current != null) {
            T game = current.data;

            if ((queryTitle.equals("*") || game.getTitle().toLowerCase().contains(queryTitle.toLowerCase())) &&
                    (queryConsole.equals("*") || game.getConsole().toLowerCase().contains(queryConsole.toLowerCase()))) {
                results.add(game);
            }

            current = current.next;
        }

        return results;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (T data : this) {
            sb.append(data.toString());
            sb.append("\n");
        }
        return sb.toString();
    }

    public Iterator<T> iterator() {
        return new LinkedListIterator();
    }

    private class Node {
        T data;
        Node next;
// Out of all things, for some reason I incorrectly constructed the below Node, It was causing me errors for hours. until I stopped ignoring it
        public Node(T data, Node next) {
            this.data = data;
            this.next = next;
        }
    }
// not too sure why I needed to iterate through the data, besides satisfying the for each operator in the advanced for argument.
    private class LinkedListIterator implements Iterator<T> {
        private Node current = head;

        public boolean hasNext() {
            return current != null;
        }

        public T next() {
            if (!hasNext()) {
                throw new NoSuchElementException();
            }

            T data = current.data;
            current = current.next;

            return data;
        }
    }
}