import java.util.Scanner;
public class DimensionTester {
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        System.out.println("Enter the value in inches:");
        double inches = input.nextDouble();
        double inFeet =  DimensionConverter.ConvertInches2Feet(inches);
        System.out.println(inches + " inches = "+ inFeet+" feet");
        System.out.println("Enter a value in feet: ");
        double feet = input.nextDouble();
        double inInches = DimensionConverter.ConvertFeet2Inches(feet);
        System.out.println(feet +" feet = "+inInches+" inches");
        //00P
        // Encapsulation, inheritance
    }
}
