public class DimensionConverter {

    public static final int FEET_TO_INCHES = 12;

    public static double ConvertFeet2Inches(double feet){
        return feet * FEET_TO_INCHES;
    }
    public static double ConvertInches2Feet(double inches){
        return inches / FEET_TO_INCHES;
    }
}
