// Aidan Hall

public class Apple {
    private String Name;
    private double Weight;
    private double price;

    // Now it is time to create my constructor.
    public Apple() {
        this.Name = "Unknown Apple";
        this.Weight = 0;
        this.price = 0;
    }
// From copying and pasting lines of code from the class notes, I had issues formatting the code the way the assignment intended.
    public String getName() {
        return this.Name;
    }
    public double getWeight(){
        return this.Weight;
    }
    public double getType(){
        return this.price;
    }

    public void setWeight(double xWeight){
        if(xWeight > 0 && xWeight < 2){
            this.Weight = xWeight;
        }
        else {
            System.out.println("invalid value entered!");
        }
    }
    public void setPrice(double xPrice){
        if(xPrice > 0 ){
        this.price = xPrice;
    }
        else {
            System.out.println("invalid value for the price of your Apple!");
    }
}
    public void setName(String xName){
        if(xName.equalsIgnoreCase("Red Delicious")
                || xName.equalsIgnoreCase("Golden Delicious")
                || xName.equalsIgnoreCase("Gala")
                || xName.equalsIgnoreCase("Granny Smith"))
        {
            this.Name = xName;
        }
        else{
            System.out.println("Invalid value entered for type of Apple!");
            System.exit(0);
        }
    }
    public String toString(){
        return "Name: "+this.Name+"\nWeight:"+ this.Weight+"\nType:"+this.price;
    }
// Mostly everything in this package file was easy to paste, I need to practice this more to get it down to muscle memory, and to do better on the next test.

}
