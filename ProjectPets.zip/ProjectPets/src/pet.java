

public class pet {
    //Encapsulation - information hiding
// instance variables
    private String name;
    private double weight;
    private String type;

    // Default constructor
    // private makes it to where the user cannot see or change this code outside of this program.
    public pet() {
        this.name = "unknown";
        this.weight = 0;
        this.type = "not specified";
    }

    //   Parameterized constructor
    public pet(String xName, double xWeight, String xType) {
        this.setName(xName);
        this.setWeight(xWeight);
        this.setType(xType);
        // to do
    }

    // accessors
    public String getName() {
    return this.name;
    }
    public double getWeight(){
        return this.weight;
    }
    public String getType(){
        return this.type;
    }
    // mutators
    public void  setName(String xName){
        this.name = xName;
    }
    public void setWeight(double xWeight){
        if(xWeight > 0 ){
            this.weight = xWeight;
        }
        else {
            System.out.println("invalid value for the weight of your pet!");
        }
    }
    public void setType(String xType){
        if(xType.equalsIgnoreCase("dog")
          || xType.equalsIgnoreCase("cat")
            || xType.equalsIgnoreCase("Hamster"))
        {
            this.type = xType;
        }
        else{
            System.out.println("Invalid value entered for type of pet!");
            System.exit(0);
        }
    }
    public String toString(){
        return "Name: "+this.name+"\nWeight:"+ this.weight+"\nType:"+this.type;
    }
    // When the value doesnt return anything use type void.
}
