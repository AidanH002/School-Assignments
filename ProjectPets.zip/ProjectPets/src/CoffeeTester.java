//Aidan Hall
import java.util.Scanner;
public class CoffeeTester {

    public static void main(String[] args){
// Ran out of time to create this after spending around 10 hours on lab 12. Although it's no excuse I  had all weekend to do this.
        Scanner input = new Scanner(System.in);

        Coffee co1 = new Coffee();

        System.out.println("Enter the name of the Coffee Brand.");

        String coffeeBrand = input.nextLine();

        System.out.println("Enter the caffeine content of the product entered.");

        double caffCont = input.nextDouble();

        Coffee Co2= new Coffee(coffeeBrand, caffCont, co1.getRiskyAmount());
        System.out.println(Co2);
// However this code is practically the same as lab 12. Students are tasked with creating their own Tester Class
        // The only thing that bothered me in this lab was creating a summary of user inputs,
        // however the program works the same, and gives the amount of cups before it becomes fatal

    }
}
