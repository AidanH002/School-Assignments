//Aidan Hall

import java.util.Scanner;

public class  AppleTester {

    public static void main(String[] args){
// One issue I had with this portion of my program, was that there were no prompts asking the user for information related to the apple.
      Scanner input = new Scanner(System.in);
      // had issues getting user to generate response.
        System.out.println("Getting first Apple type...");

        Apple a1 = new Apple();
        a1.setName("Red Delicious");
        a1.setWeight(.5);
        a1.setPrice(.65);
        System.out.println(a1.getName());
        System.out.println(a1.getWeight()+ " kg");
        System.out.println(a1.getType());

        System.out.println("Getting second Apple type...");
        Apple a2 = new Apple();
        a2.setName("Golden Delicious");
        a2.setWeight(.6);
        a2.setPrice(.75);
        System.out.println(a2.getName());
        System.out.println(a2.getWeight()+ " kg");
        System.out.println(a2.getType());

       System.out.println("Getting third Apple type...");
        Apple a3 = new Apple();
        a3.setName("Gala");
        a3.setWeight(.65);
        a3.setPrice(.85);
        System.out.println(a3.getName());
        System.out.println(a3.getWeight()+ " kg");
        System.out.println(a3.getType());

        System.out.println("Getting fourth Apple type...");
// Forgot to change the number that identifies the apple. so they all pasted the first apple values.
        Apple a4 = new Apple();
        a4.setName("Granny Smith");
        a4.setWeight(.7);
        a4.setPrice(1);
        System.out.println(a4.getName());
        System.out.println(a4.getWeight()+ " kg");
        System.out.println(a4.getType());
        System.out.println("Getting fifth Apple type...");
        Apple a5 = new Apple();
        a5.setName("Bobby Smith");
        a5.setWeight(-007);
        a5.setPrice(-200);
        System.out.println(a5.getName());
        System.out.println(a5.getWeight()+ " kg");
        System.out.println(a5.getType());

    }
}
