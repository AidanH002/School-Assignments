public class PetsDemo {

    public static void main(String[] args){

        pet p1 = new pet();

        p1.setName("Sparky");
        p1.setWeight(100);
        p1.setType("dog");

        System.out.println(p1.getName());
        System.out.println(p1.getWeight()+ " lbs");
        System.out.println(p1.getType());

        pet p2 = new pet("Socks", 5, "cat");

        System.out.println(p2.toString());
    }
}
