//Aidan hall
public class Coffee {
    private String Brand;

private double CafCont;

private double riskyAmount;
//Variables
public Coffee() {
// Default constructor
    this.Brand = "Unknown Coffee";
    this.CafCont = 1;
    this.riskyAmount = 1;
}
// Parameterized constructor
    public Coffee(String xBrand, double xCafCont,double xRiskyAmount){
    this.setBrand(xBrand);
    this.setCafCont(xCafCont);
    this.setRiskyAmount(xRiskyAmount);

    }
// Retrievers/ getters below
    public String getBrand(){return this.Brand;}

    public double getCafCont(){return this.CafCont;}

    public double getRiskyAmount(){return this.riskyAmount;}

   public void setBrand(String xBrand){
        this.Brand = xBrand;
   }
    public void setCafCont(double xCafCont){
        if (xCafCont > 50 && xCafCont < 300){
            this.CafCont = xCafCont;

        }
        else {
            System.out.println("Invalid caffeine content input entered.");
        }
    }
    public void setRiskyAmount(double xRiskyAmount){
        double cupsAmount = 180.0/(CafCont / 100.0)*6.0;
        this.riskyAmount = xRiskyAmount;
        System.out.println(" The amount of cups it takes before this brand of coffee becomes dangerous is: "+cupsAmount + " cups");
    }
// Very easy to create after lab 12.


}
