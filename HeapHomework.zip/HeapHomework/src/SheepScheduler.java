//Aidan hall
import java.io.IOException;
import java.util.Scanner;
// Here is the front end file where the user inputs the file in contrary to the assignment details.
// it does read the file however it requires the user to input the name of the file.
public class SheepScheduler {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        boolean continueRunning = true;

        while (continueRunning) {
            System.out.print("Enter the name of the file containing the sheep schedule: ");
            String filename = scanner.nextLine();

            try {
                Sheep[] sheepList = FileIO.readSheepFile(filename);
                MinHeap<Sheep> waitingSheep = new MinHeap<>();
                for (Sheep sheep : sheepList) {
                    waitingSheep.add(sheep);
                }

                int currentTime = 0;
                while (!waitingSheep.isEmpty()) {
                    Sheep nextSheep = waitingSheep.remove();
                    int waitTime = nextSheep.getArrivalTime() - currentTime;
                    if (waitTime > 0) {
                        currentTime += waitTime;
                    }
                    System.out.println("Shearing " + nextSheep.getName() + " Shearing Time: " + nextSheep.getShearingTime() + " Arrival Time: " + nextSheep.getArrivalTime());
                    currentTime += nextSheep.getShearingTime();
                }

                System.out.println("All sheep have been sheared!");

                continueRunning = false;
            } catch (IOException e) {
                System.out.println("Error reading file: " + e.getMessage());
            } catch (IllegalArgumentException e) {
                System.out.println("Error processing file: " + e.getMessage());
            }
        }
    }
}
