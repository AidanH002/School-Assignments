// Aidan Hall
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class FileIO {

    public static Sheep[] readSheepFile(String filename) throws IOException {
        int count = 0;
        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            while (reader.readLine() != null) {
                count++;
            }
        }
// Properly reads the file based off of the specifications listed in the assignment details
        Sheep[] sheepList = new Sheep[count];
        int index = 0;
        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] values = line.split("\t");
                if (values.length != 3) {
                    throw new IllegalArgumentException("Invalid input file format");
                }
                String name = values[0];
                int shearingTime = Integer.parseInt(values[1]);
                int arrivalTime = Integer.parseInt(values[2]);
                Sheep sheep = new Sheep(name, shearingTime, arrivalTime);
                sheepList[index++] = sheep;
            }
        }
        return sheepList;
    }
}

