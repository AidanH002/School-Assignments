// Aidan Hall
import java.util.NoSuchElementException;
// This is the generally constructed minheap that utilizes adding and removing
public class MinHeap<T extends Comparable<T>> {
    private Object[] items;
    private int size;

    public MinHeap() {
        items = new Object[10];
        size = 0;
    }

    public void add(T item) {
        ensureCapacity();
        items[size] = item;
        int currentIndex = size;
        while (currentIndex > 0) {
            int parentIndex = (currentIndex - 1) / 2;
            T parentItem = (T) items[parentIndex];
            if (item.compareTo(parentItem) >= 0) {
                break;
            }
            items[currentIndex] = parentItem;
            currentIndex = parentIndex;
        }
        items[currentIndex] = item;
        size++;
    }

    public T remove() {
        if (isEmpty()) {
            throw new NoSuchElementException();
        }
        T rootItem = (T) items[0];
        T lastItem = (T) items[size - 1];
        items[size - 1] = null;
        size--;
        if (size > 0) {
            items[0] = lastItem;
            int currentIndex = 0;
            while (currentIndex < size / 2) {
                int leftChildIndex = 2 * currentIndex + 1;
                int rightChildIndex = 2 * currentIndex + 2;
                int smallerChildIndex = leftChildIndex;
                if (rightChildIndex < size && ((T) items[rightChildIndex]).compareTo((T) items[leftChildIndex]) < 0) {
                    smallerChildIndex = rightChildIndex;
                }
                if (lastItem.compareTo((T) items[smallerChildIndex]) <= 0) {
                    break;
                }
                items[currentIndex] = items[smallerChildIndex];
                currentIndex = smallerChildIndex;
            }
            items[currentIndex] = lastItem;
        }
        return rootItem;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    private void ensureCapacity() {
        if (size == items.length) {
            Object[] newItems = new Object[items.length * 2];
            System.arraycopy(items, 0, newItems, 0, items.length);
            items = newItems;
        }
    }
}
