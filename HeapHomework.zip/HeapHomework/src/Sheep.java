//Aidan Hall
// This class describes the sheep object enabling the comparison between two sheep.
public class Sheep implements Comparable<Sheep> {
    private String name;
    private int shearingTime;
    private int arrivalTime;

    public Sheep(String name, int shearingTime, int arrivalTime) {
        this.name = name;
        this.shearingTime = shearingTime;
        this.arrivalTime = arrivalTime;
    }

    public String getName() {
        return name;
    }

    public int getShearingTime() {
        return shearingTime;
    }

    public int getArrivalTime() {
        return arrivalTime;
    }
// From this line i'm pretty sure It sorts alphabetically however I was skeptical over it.
    public int compareTo(Sheep other) {
        int result = Integer.compare(this.shearingTime, other.shearingTime);
        if (result == 0) {
            result = this.name.compareTo(other.name);
        }
        return result;
    }
}