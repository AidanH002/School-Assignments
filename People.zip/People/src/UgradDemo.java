public class UgradDemo {
    public static void main(String[] args){
        Undergrad ug = new Undergrad("Steve", 19, 1234, "chemistry",3.9, 2,"Finance");
        ug.writeOutput();
    }
}
