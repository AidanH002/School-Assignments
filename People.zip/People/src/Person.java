public class Person {
    private String name;
    private int age;

    public Person(){
        this.name = "No name yet";
        this.age = 0;
    }

    public Person(String xName, int xAge){
        this.setName(xName);
        this.setAge(xAge);
    }
    public String getName(){
        return this.name;
    }
    public int getAge(){
        return this.age;
    }
    // Mutators

    public void setName(String xName) {
        this.name = xName;
    }
    public void setAge(int xAge){
        if (xAge >= 0){
            this.age = xAge;
        }
        else {
            System.out.println("Invalid value for age!");
        }
    }
    public void writeOutput(){
        System.out.println("Name:"+ this.name+"Age: "+ this.age+" years");

    }

}
