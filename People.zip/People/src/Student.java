public class Student extends Person {
    // Graduation year, major, GPA, ID
    private int studentID;
    private String Major;
    private double gpa;
    //default constructor
    public Student(){
        super(); // calls the parents default constructor
        this.studentID = 1;
        this.Major = "Unknown";
        this.gpa = 1;
    }
    // Parameterized Constructor
    public Student(String xName, int xAge, int xStudentID, String xMajor, double xGpa){
        super(xName, xAge);     // call to the parent's parameterized constructor
        this.setStudentID(xStudentID);
        this.setMajor(xMajor);
        this.setGpa(xGpa);
    }
    // accessors
    public int getStudentID(){
        return this.studentID;
    }
    public String getMajor(){
        return this.Major;
    }
    public double getGpa(){
        return this.gpa;
    }
    //Mutators
    public void setStudentID(int xStudentID) {
        if (xStudentID >= 1){
            this.studentID = xStudentID;
        }
        else {
            System.out.println("Invalid value entered for student ID!");
        }
    }
    public void setMajor(String xMajor){
        if(xMajor.equalsIgnoreCase("Electical Engineering")
        || xMajor.equalsIgnoreCase("Computer Science")
        || xMajor.equalsIgnoreCase("Chemistry")
        || xMajor.equalsIgnoreCase("Mathematics")
        || xMajor.equalsIgnoreCase("Art History"))
        {
            this.Major = xMajor;
        }
        else {
            System.out.println("Invalid major entered");
        }
    }
    public void setGpa(double xGpa){
        if (xGpa >= 1 && xGpa <= 4){
            this.gpa = xGpa;
        }
        else {
            System.out.println("Invalid value for student GPA!");
        }
        // UML Diagram - unified modeling language
        // In shopping class, Shopping becomes rule one of the diagram.
        // use negative sign to indicate private variables
        // for data, use - name: String
        // same for - price: double
        //same for quantity, - quantity : int
        // Then list public Accessors
        // For public use + operator
        //+ getName():String
        //+ getPrice():Double
        //+ getQuantity(): int
        // For mutators, since theyre public use -
        // +setName(String xName):
        //+ setPrice(double xPrice): void
        //
    }
    public void writeOutput(){
        super.writeOutput();
      System.out.println("Student ID: "+this.studentID +"\nMajor:"+ this.Major+"\nGPA: "+this.gpa);


    }
}
