public class Undergrad extends Student {
    private int level;
    private String minor;

    public Undergrad(){
        super();
        this.level = 1;
        this.minor = "no minor selected";
    }
    //Parameterized constructor
    public Undergrad(String xName, int xAge, int xStudentID, String xMajor, double xGPA, int xLevel, String xMinor){
        super(xName,xAge,xStudentID,xMajor,xGPA);
        this.setLevel(xLevel);
        this.setMinor(xMinor);
    }
    public int getLevel(){
        return this.level;
    }
    public String getMinor(){
        return this.minor;
    }

    public void setLevel(int xLevel){
        if(xLevel >= 1 && xLevel <=4){
            this.level = xLevel;
        }
        else{
            System.out.println("Invalid student level entered!");
        }
    }
    public void setMinor(String xMinor){
        if(xMinor.equalsIgnoreCase("Finance")
        || xMinor.equalsIgnoreCase("Business")
        || xMinor.equalsIgnoreCase("Mechanical engineering")){
            this.minor = xMinor;
        }
        else{
            System.out.println("Invalid value for student minor!");
        }
    }
    public void writeOutput(){
        super.writeOutput();
        System.out.println("Student Level:" +this.level+"\nMinor:"+this.minor);
    }
}
