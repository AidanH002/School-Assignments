import java.util.Scanner;

public class Sort {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String[] strings = new String[0];
        boolean sorting = true;

        while (sorting) {
            System.out.println("Enter any number of strings and I will sort by SORT's. Once you're done entering sentences enter \"quit\".");

            // Read input strings and add them to the array
            while (true) {
                String input = scanner.nextLine().toUpperCase();
                if (input.equals("QUIT")) break;
                strings = addString(strings, input);
            }

            // Sort the strings by the number of occurrences of "SORT"
            mergeSort(strings, 0, strings.length - 1);

            // Print the sorted strings
            System.out.println("SORT SORTED!");
            for (String s : strings) {
                System.out.println(s);
            }

            // Ask the user if they want to sort more strings
            System.out.println("Would you like to sort more Strings?");
            String answer = scanner.nextLine().toUpperCase();
            sorting = answer.equals("YES");
        }

        System.out.println("Goodbye!");
    }

    // Adds a new string to the end of the array
    private static String[] addString(String[] strings, String s) {
        String[] newStrings = new String[strings.length + 1];
        System.arraycopy(strings, 0, newStrings, 0, strings.length);
        newStrings[strings.length] = s;
        return newStrings;
    }

    // Sorts the array of strings by the number of occurrences of "SORT"
    private static void mergeSort(String[] strings, int start, int end) {
        if (start < end) {
            int mid = (start + end) / 2;
            mergeSort(strings, start, mid);
            mergeSort(strings, mid + 1, end);
            merge(strings, start, mid, end);
        }
    }

    // Merges two sorted sub-arrays into one sorted array
    private static void merge(String[] strings, int start, int mid, int end) {
        String[] temp = new String[end - start + 1];
        int i = start, j = mid + 1, k = 0;

        while (i <= mid && j <= end) {
            int sortCount1 = countSort(strings[i]);
            int sortCount2 = countSort(strings[j]);
            if (sortCount1 < sortCount2) {
                temp[k++] = strings[i++];
            } else if (sortCount1 > sortCount2) {
                temp[k++] = strings[j++];
            } else {
                // If the number of occurrences of "SORT" is the same for both strings, sort alphabetically
                int compareResult = strings[i].compareTo(strings[j]);
                if (compareResult <= 0) {
                    temp[k++] = strings[i++];
                } else {
                    temp[k++] = strings[j++];
                }
            }
        }

        while (i <= mid) {
            temp[k++] = strings[i++];
        }

        while (j <= end) {
            temp[k++] = strings[j++];
        }

        System.arraycopy(temp, 0, strings, start, temp.length);
    }
    // Counts the number of times the word "SORT" appears in a string
    private static int countSort(String s) {
        int count = 0;
        for (int i = 0; i < s.length() - 3; i++) {
            if (s.substring(i, i + 4).equals("SORT")) {
                count++;
            }
        }
        return count;
    }
}

