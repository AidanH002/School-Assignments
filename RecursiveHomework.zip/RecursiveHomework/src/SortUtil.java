import java.util.Comparator;

public class SortUtil {

    public static String[] sortStrings(String[] strings, int count) {
        String[] newStrings = new String[count];
        GenLL<String>[] counts = new GenLL[count + 1];

        for (int i = 0; i < counts.length; i++) {
            counts[i] = new GenLL<>();
        }

        for (String s : strings) {
            int numSorts = countSorts(s);
            counts[numSorts].add(s);
        }

        int index = 0;
        for (int i = 0; i < counts.length; i++) {
            GenLL<String> list = counts[i];
            for (int j = 0; j < list.size(); j++) {
                newStrings[index] = list.get(j);
                index++;
            }
        }

        return newStrings;
    }

    public static int countSorts(String s) {
        if (s == null || s.isEmpty()) {
            return 0;
        }
        String[] words = s.split("\\s+");
        int count = 0;
        for (String word : words) {
            if (word.equalsIgnoreCase("SORT")) {
                count++;
            }
        }
        return count;
    }

    public static <T extends Comparable<? super T>> void mergeSort(T[] array) {
        mergeSort(array, Comparator.naturalOrder());
    }

    public static <T> void mergeSort(T[] array, Comparator<? super T> comparator) {
        if (array.length > 1) {
            int middle = array.length / 2;
            T[] left = (T[]) new Object[middle];
            T[] right = (T[]) new Object[array.length - middle];

            System.arraycopy(array, 0, left, 0, middle);
            System.arraycopy(array, middle, right, 0, array.length - middle);

            mergeSort(left, comparator);
            mergeSort(right, comparator);

            int i = 0;
            int j = 0;
            int k = 0;

            while (i < left.length && j < right.length) {
                if (comparator.compare(left[i], right[j]) <= 0) {
                    array[k] = left[i];
                    i++;
                } else {
                    array[k] = right[j];
                    j++;
                }
                k++;
            }

            while (i < left.length) {
                array[k] = left[i];
                i++;
                k++;
            }

            while (j < right.length) {
                array[k] = right[j];
                j++;
                k++;
            }
        }
    }
}



