// Aidan Hall
import java.util.Iterator;

public class GenLL<T> implements Iterable<T> {
    private class ListNode {
        T data;
        ListNode link; // Ref to the next node

        public ListNode(T aData, ListNode aLink) {
            this.data = aData;
            this.link = aLink;
        }
    }

    private ListNode head; // Reference to the first element.
    private ListNode current; // movable reference.
    private ListNode previous; // One behind the current previous.link == current

    public boolean isEmpty() {
        return head == null;
    }
    private int size;

    public GenLL() {
        head = current = previous = null;
        this.size = 0;
    }

    // Head -> X(null)
    public void add(T aData) {
        if (aData == null)
            return;

        ListNode newNode = new ListNode(aData, null);
        if (head == null) {
            // empty list
            head = current = newNode;
            this.size = 1;
            return;
        }

        ListNode temp = head;
        while (temp.link != null)
            temp = temp.link;
        temp.link = newNode;
        this.size++;
    }

    public T getCurrent() {
        if (current == null)
            return null;

        return current.data;
    }
    public void gotoNext() {
        if (current == null)
            return;

        previous = current;
        current = current.link;
    }

    public void reset() {
        current = head;
        previous = null;
    }

    public void removeCurrent(T t) {
        if (head == current) {
            head = head.link;
            current = head;
        } else {
            previous.link = current.link;
            current = current.link;
        }

        if (this.size > 0)
            this.size--;
    }

    public int getSize() {
        return this.size;
    }

    // Iterator implementation
    public Iterator<T> iterator() {
        return new GenLLIterator();
    }

    private class GenLLIterator implements Iterator<T> {
        private ListNode current;

        public GenLLIterator() {
            current = head;
        }

        public boolean hasNext() {
            return current != null;
        }

        public T next() {
            if (!hasNext())
                return null;

            T data = current.data;
            current = current.link;
            return data;
        }

        public void remove() {
            throw new UnsupportedOperationException();
        }
    }
}

