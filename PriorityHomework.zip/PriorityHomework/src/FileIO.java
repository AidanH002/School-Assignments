// Aidan hall
import java.io.*;
import java.util.Scanner;

// This class contains all of my file operations. I thought I'd separate its class for reference.
public class FileIO {
    public static void readFile(String filename, TaskManager taskList) {
        try {
            Scanner scanner = new Scanner(new File(filename));
            scanner.useDelimiter("\\t"); // set delimiter to tab character
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] fields = line.split("\\t");
                if (fields.length != 2) {
                    continue;
                }
                try {
                    int priority = Integer.parseInt(fields[0].trim());
                    Task task = new Task(priority, fields[1].trim());
                    taskList.addTask(task);
                } catch (NumberFormatException e) {
                    System.out.println("Invalid priority value for task: " + line);
                }
            }
            scanner.close();
        } catch (FileNotFoundException e) {
            System.out.println("File not found.");
        }
    }

    public static void writeToFile(String fileName, TaskManager data) {
        try (FileWriter writer = new FileWriter(fileName)) {
            for (Task task : data) {
                writer.write(task.getPriority() + "\t" + task.getDescription() + "\n");
            }
            System.out.println("Tasks printed to file.");
        } catch (IOException e) {
            System.out.println("Error writing to file.");
        }
    }
}
