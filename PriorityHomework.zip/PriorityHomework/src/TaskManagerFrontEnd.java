// Aidan Hall
import java.util.Scanner;

public class TaskManagerFrontEnd {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        TaskManager taskManager = new TaskManager();

        boolean loop = true;
        while (loop) {
            System.out.println("Select an option:");
            System.out.println("1. Load tasks from file");
            System.out.println("2. Add a task");
            System.out.println("3. Remove a task");
            System.out.println("4. Print tasks to console");
            System.out.println("5. Print tasks to file");
            System.out.println("6. Quit");

            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1 -> {
                    System.out.println("Enter the name of the file to load tasks from:");
                    String fileName = scanner.nextLine();
                    FileIO.readFile(fileName, taskManager);
                }
                case 2 -> {
                    System.out.println("Enter task description:");
                    String description = scanner.nextLine();
                    System.out.println("Enter task priority (1-5):");
                    int priority = scanner.nextInt();
                    scanner.nextLine();
                    taskManager.addTask(new Task(priority, description));
                    System.out.println("Task added.");
                }
                case 3 -> {
                    System.out.println("Enter task index:");
                    int index = scanner.nextInt();
                    scanner.nextLine();
                    taskManager.removeTask(index);
                }
                case 4 -> {
                    try {
                        System.out.println("Tasks:");
                        taskManager.printTasksToConsole();
                    } catch (NullPointerException e) {
                        System.out.println("No tasks found.");
                    }
                }
                case 5 -> {
                    System.out.println("Enter the name of the file to save tasks to:");
                    String fileName = scanner.nextLine();
                    FileIO.writeToFile(fileName, taskManager);
                }
                case 6 -> loop = false;
                default -> System.out.println("Invalid option.");
            }
        }

        scanner.close();
    }
}


