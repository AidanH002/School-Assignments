// Aidan hall
import java.util.Iterator;

public class TaskManager implements Iterable<Task> {
    private final GenLL<Task> tasks = new GenLL<>();

    private final GenLL<Task>[] organizedTasks;

    public TaskManager() {
        // Create an array of 5 linked lists of tasks
        organizedTasks = new GenLL[5];
        for (int i = 0; i < organizedTasks.length; i++) {
            organizedTasks[i] = new GenLL<Task>();
        }
    }

    public void removeTask(int index) {
        if (index < 0 || index >= tasks.getSize()) {
            System.out.println("Invalid task index.");
            return;
        }
        tasks.reset();
        for (int i = 0; i < index; i++) {
            tasks.gotoNext();
        }
        Task removedTask = tasks.getCurrent();
        tasks.removeCurrent(removedTask);
        System.out.println("Task removed: " + removedTask.getDescription());
    }

    public void addTask(Task task) {
        // Add task to the correct linked list based on priority
        int priority = task.getPriority();
        if (priority >= 1 && priority <= 5) {
            organizedTasks[priority - 1].add(task);
            tasks.add(task);
        }
    }

    public void printTasksToConsole() throws NullPointerException {
        boolean foundTask = false;
        for (int i = 0; i < organizedTasks.length; i++) {
            GenLL<Task> currentPriority = organizedTasks[i];
            if (!currentPriority.isEmpty()) {
                foundTask = true;
                System.out.println("Priority " + (i + 1) + ":");
                currentPriority.reset();
                for (int j = 0; j < currentPriority.getSize(); j++) {
                    Task currentTask = currentPriority.getCurrent();
                    System.out.println("[Task] Priority: " + currentTask.getPriority() + "\t" +"Task: " + currentTask.getDescription());
                    currentPriority.gotoNext();
                }
            }
        }
        if (!foundTask) {
            System.out.println("No tasks found.");
        }
    }


    public Iterator<Task> iterator() {
        return tasks.iterator();
    }
}
