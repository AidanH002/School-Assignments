public class Concert {
    private String name;

    private int capacity;

    private int  numTicketsByPhone;

    private int numTicketsAtVenue;

    private int ticketsRemaining;

    private int totalNumberOfTicketsSold;

    private double buyTicketsByPhone;

    private double buyTicketsAtVenue;

    public Concert(){
        this.name = "Unknown Concert";
        this.capacity = 0;
        this.numTicketsByPhone = 0;
        this.numTicketsAtVenue = 0;
        this.buyTicketsByPhone = 0;
        this.buyTicketsAtVenue = 0;
    }
    public Concert(String xBandName, int capacity, double priceByPhone, double priceAtVenue){
        this.setBandName(xBandName);
        this.setCapacity(capacity);
        this.setPriceByPhone(priceByPhone);
        this.setPriceAtVenue(priceAtVenue);
    }
    public Concert(String xBandName,int capacity,int numTicketsAtVenue, int numTicketsByPhone, double priceByPhone, double PriceAtVenue ){
        this.setBandName(xBandName);
        this.setCapacity(capacity);
        this.setNumTicketsAtVenue(numTicketsAtVenue);
        this.setnumTicketsByPhone(numTicketsByPhone);
        this.setPriceByPhone(priceByPhone);
        this.setPriceAtVenue(PriceAtVenue);
//Didnt finish construction until after the lab. Reading the instructions really helps in this class, yet I still lack the ability to do so consistently to complete the lab in a timely fashion.
    }
    public String getBandName(){return this.name;}
    public int getCapacity(){return this.capacity;}
//
    public double buyTicketsByPhone(){return this.buyTicketsByPhone;}
    public double buyTicketsByVenue(){return this.buyTicketsAtVenue;}
    public int getTotalNumberOfTicketsSold(){return this.totalNumberOfTicketsSold;}
    public int getNumTicketsAtVenue(){return this.numTicketsAtVenue;}
    public int getTicketsRemaining(){return this.ticketsRemaining;}
    public int getTicketsSoldAtVenue(){return this.numTicketsAtVenue;}
    public int getTicketsSoldByPhone(){return this.numTicketsByPhone;}
    public int getNumTicketsSoldByPhone() {return numTicketsByPhone;}
    public int getNumTicketsSoldAtVenue() {return numTicketsAtVenue;}
    public int totalNumberOfTicketsSold() {return totalNumberOfTicketsSold;}
    public int totalSales() {return (numTicketsAtVenue + numTicketsByPhone);}
    // I really did not realize that I had to retrieve this many values for this program.

//Statements below are all out of order, I felt like solving everything after this point was like completing a puzzle.
    public void setBandName(String xBandName){
        this.name = xBandName;
    }
    public void setCapacity(int xCapacity){
        if (capacity > 0){
            this.capacity = xCapacity;
        }
        else System.out.println("Invalid input entered for Concert Capacity!");
    }
    public void setnumTicketsByPhone(int xBuyTicketsByPhone){
        if (buyTicketsByPhone > 0){
            this.buyTicketsByPhone = xBuyTicketsByPhone;
        }
        else System.out.println("Invalid amount entered for tickets to be bought by phone!");
    }
    public void buyTicketsAtVenue(int xbuyTicketsByVenue){
        if (buyTicketsAtVenue > 0){
            this.buyTicketsAtVenue = xbuyTicketsByVenue;
        }
        else System.out.println("Invalid amount entered for tickets to be bought at venue!");
    }
    public void setNumTicketsAtVenue(int xNumTicketsAtVenue){
        if (numTicketsAtVenue <= capacity && numTicketsAtVenue > 0){
            numTicketsAtVenue = xNumTicketsAtVenue;
        }
        else System.out.println("Invalid number of tickets at venue!");
    }
    public void setPriceByPhone(double xNumTicketsByPhone){
        if (numTicketsByPhone >= buyTicketsByPhone){
            this.numTicketsByPhone = (int) xNumTicketsByPhone;
        }
        else System.out.println("Invalid Input entered for price of tickets by phone!");
    }
    public void setPriceAtVenue(double xNumTicketsSoldByVenue){
        if (numTicketsAtVenue >= buyTicketsAtVenue){
            this.numTicketsAtVenue = (int) xNumTicketsSoldByVenue;
        }
        else System.out.println("Invalid input entered for price of tickets by  by venue!");
    }

    public void setTotalNumberOfTicketsSold(int xTotalNumberOfTicketsSold){
        if (totalNumberOfTicketsSold >= capacity && (totalNumberOfTicketsSold > 0)){
            xTotalNumberOfTicketsSold = (numTicketsAtVenue + numTicketsByPhone);
            xTotalNumberOfTicketsSold  = totalNumberOfTicketsSold;
        }
        else System.out.println("Logical Error found! Total number of tickets is greater than ticket!");
    }
    public void setTicketsRemaining(int xTicketsRemaining){
        if (ticketsRemaining > 0){
            ticketsRemaining = xTicketsRemaining;
        }
        else System.out.println("Invalid tickets remaining! Logical Error found!");
    }

    public void setNumTicketsSoldByPhone(int xNumTicketByPhone) {
        if (numTicketsByPhone > 0 && (numTicketsByPhone + numTicketsAtVenue) < capacity)  {
            numTicketsByPhone = xNumTicketByPhone;
        }
        else System.out.println("Invalid amount found for Number of tickets sold by phone!");
    }
    public int setNumTicketsSoldAtVenue(int xNumTicketsAtVenue) {
        if (numTicketsAtVenue > 0 && (numTicketsAtVenue + numTicketsByPhone) < capacity){
            numTicketsAtVenue = xNumTicketsAtVenue;
        }
        else System.out.println("Invalid amount found for number of tickets sold at venue!");
        return xNumTicketsAtVenue;
    }

    public void buyTicketsByPhone(int xBuyTicketsByPhone) {
        if (buyTicketsByPhone >= 0 && buyTicketsByPhone > capacity){
            buyTicketsByPhone = xBuyTicketsByPhone;
        }
    }

    public int ticketsRemaining() {
        if ( ticketsRemaining > -1 && ticketsRemaining <= capacity){
        }
        else System.out.println("Invalid amount found for Tickets Remaining!");
        return 0;
    }

    public void NumTicketsSoldAtVenue(int xnumTicketsSoldAtVenue) {
        if (numTicketsAtVenue >= 0 && numTicketsAtVenue < capacity){
               numTicketsAtVenue = xnumTicketsSoldAtVenue;
    }
    }
    // While the program did take around 10 hours of my day to complete, I did learn a few things about this program. I also enjoyed working with another persons code.
    // I felt that working with another persons code was more challenging yes, However I feel like I will come across this many times in my career.
}
